import random
import os

def result(comp, player):
    if((comp == "stone") and (player == "paper")or
       (comp == "paper") and (player == "scissors")or
       (comp == "scissors") and (player == "stone")):
        print("You Win !!")
        return True
    elif(comp == player):
        print("Uh OH, same choice, let's try again !!")
        return False
    else:
        print("Computers Win !!")
        return True

def inputgame():

    with open(r"C:\Users\admin\Documents\python\Project 1\reply.txt", "r", encoding="utf-8") as file:
        reply = [line.strip() for line in file.readlines()]
    choices = ["stone", "paper", "scissors"]
    while True : 
        computer_choice = random.choice(choices)
        player = input("STONE, PAPER or SCISSORS?(enter correct spelling) :").lower()
        if(player not in choices):
            print(random.choice(reply))
            continue
        print(f"Your choice : {player} [and] Computer's choice = {computer_choice}")
        if result(computer_choice, player):
            break

inputgame()